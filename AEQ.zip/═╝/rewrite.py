# -*- coding:utf8 -*-
import  json
from os import listdir
import os
from xlrd.formula import rangename2d
import xlwt
import xlrd


path = 'C:/Users/jackey_gu/Desktop/图/'
 
filelist = listdir(path)
#for i in  filelist:
#print(filelist[0].split(".")[0])
 #   i.split()
fileIndex =[]

#打开excel工作表,获取sheet
ExcelFile = xlrd.open_workbook(path+'实验数据.xls')
sheet_me=ExcelFile.sheet_by_index(0)

# 创建excel工作表
workbook = xlwt.Workbook(encoding='utf-8')
worksheet = workbook.add_sheet('sheet1')

# print (sheet_me.name,sheet_me.nrows,sheet_me.ncols)


# 设置表头,第零行内容
# worksheet.write(0, 0, label='bs-rwmix-iodepth-num-repeat')
# worksheet.write(0, 1, label='read_lat')
# worksheet.write(0, 2, label='read_95_lat')
# worksheet.write(0, 3, label='read_99_lat')
# worksheet.write(0, 4, label='read_bw_kb')
# worksheet.write(0, 5, label='read_iops')
# worksheet.write(0, 6, label='write_lat')
# worksheet.write(0, 7, label='write_95_lat')
# worksheet.write(0, 8, label='write_99_lat')
# worksheet.write(0, 9, label='write_bw_kb')
# worksheet.write(0, 10, label='write_iops')
# worksheet.write(0, 11, label='sys_cpu')

row0 = 0
column0 = 1
row1 = 0
column1 = 0

#print (sheet_me.cell_value(2,0))


while row0 <= 752 :
    while column0 <= 168 :
        val = sheet_me.cell_value(row0,column0)
        worksheet.write(row1,column1,val)
        column1 += 1
        column0 += 12
    column1 = 0
    column0 = 1
    row1 += 1
    row0 += 1

# while row0 <= 752 :
#     while column0 <= 168 :


#         worksheet.write(row1,column1,val2)
#         worksheet.write(row1,column1,val3)

#     column0 += 12 

# row0 += 1

workbook.save('read_lat.xls')
   