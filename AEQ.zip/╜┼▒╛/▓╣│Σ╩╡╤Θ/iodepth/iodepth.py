# -*- coding:utf8 -*-
import  json
from os import listdir
import os
import xlwt
import xlrd
 
fileIndex =[]

# 创建excel工作表
workbook = xlwt.Workbook(encoding='utf-8')
worksheet = workbook.add_sheet('sheet1')


#文件名载入
bs = 4
iodepth = 1
rwmixwrite = 0
num = 1
repeat = 1
while bs <= 4:  
    while rwmixwrite <= 0:  
        while iodepth <= 1:
            while num <= 12:          
                while repeat <= 3: 
                    output="test"+str(bs)+'k'+'-'+str(rwmixwrite)+'-'+str(iodepth)+'-'+str(num)+'-'+str(repeat)
                    fileIndex.append(output)
                    #print(output)
                    repeat += 1
                repeat = 1    
                num += 11
            num = 1
            iodepth = iodepth * 2  
        iodepth = 1      
        rwmixwrite += 25 
    rwmixwrite = 0   
    bs *= 2
# print(fileIndex)


# 设置表头,第零行内容
worksheet.write(0, 0, label='bs-rwmix-iodepth-num-repeat')
worksheet.write(0, 1, label='read_lat')
worksheet.write(0, 2, label='read_95_lat')
worksheet.write(0, 3, label='read_99_lat')
worksheet.write(0, 4, label='read_bw_kb')
worksheet.write(0, 5, label='read_iops')
worksheet.write(0, 6, label='write_lat')
worksheet.write(0, 7, label='write_95_lat')
worksheet.write(0, 8, label='write_99_lat')
worksheet.write(0, 9, label='write_bw_kb')
worksheet.write(0, 10, label='write_iops')
worksheet.write(0, 11, label='sys_cpu')


# 将json字典写入excel
# 变量用来循环时控制写入单元格，感觉有更好的表达方式

row0 = 1
column0 = 0
row1 = 1


#完成排序后，开始按照文件名顺序读取文件内容信息
#记录每个文件最终信息的列表
labelpath = 'C:/Users/jackey_gu/Desktop/脚本/补充实验/iodepth/RWSA/'
for file in fileIndex:
    #print(file)
    # 读取json文件
    worksheet.write(row0,column0,file)
    try:
        with open(labelpath + file, 'r') as f:
            data = json.load(f)
    except Exception as e:  
            print(file)
            workbook.save('RWSA.xls')  
        #print(data)
        # 写入内容  ws.write(a, b, c)  a：行，b：列，c：内容
    val1 = data['jobs'][0]['read']['clat_ns']['mean']
    val2 = data['jobs'][0]['read']['clat_ns']['percentile']['95.000000']
    val3 = data['jobs'][0]['read']['clat_ns']['percentile']['99.000000']
    val4 = data['jobs'][0]['read']['bw']
    val5 = data['jobs'][0]['read']['iops']
    val6 = data['jobs'][0]['write']['clat_ns']['mean']
    val7 = data['jobs'][0]['write']['clat_ns']['percentile']['95.000000']
    val8 = data['jobs'][0]['write']['clat_ns']['percentile']['99.000000']
    val9 = data['jobs'][0]['write']['bw']
    val10 = data['jobs'][0]['write']['iops']
    val11 = data['jobs'][0]['sys_cpu']
    worksheet.write(row1,1,val1)
    worksheet.write(row1,2,val2)
    worksheet.write(row1,3,val3)
    worksheet.write(row1,4,val4)
    worksheet.write(row1,5,val5)
    worksheet.write(row1,6,val6)
    worksheet.write(row1,7,val7)
    worksheet.write(row1,8,val8)
    worksheet.write(row1,9,val9)
    worksheet.write(row1,10,val10)
    worksheet.write(row1,11,val11)
    #print(val1) 
        
    row1 += 1
    row0 += 1

# 表格保存
workbook.save('RWSA.xls')