#! /bin/bash -v
rw=write
for ((bs = 4;bs <= 64; bs += 4))
do
for ((num = 1; num <= 24; num++ ))
do
for ((iodepth = 8; iodepth <= 128; iodepth = iodepth * 2 ))
do
for((repeat = 1; repeat <= 5; repeat++))
do
    echo "rw= "$rw "bs= "$bs"k"  "num= "$num  "iodepth="$iodepth "repeat="$repeat 
    fio --direct=1 --ioengine=libaio --group_reporting=1 --size=15G --group_reporting --time_based --runtime=600 --iodepth=$iodepth --numjobs=$num --bs=$bs'k' --rw=$rw --cpus_allowed=0-23 --name=nvme0n1 --filename=/dev/nvme0n1 --output=test$num-$repeat --output-format=json
done
done
done
done