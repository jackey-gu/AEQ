#! /bin/bash -v
rw=randrw
for ((bs = 64;bs <= 64; bs *= 2))
do
for ((rwmixwrite = 100; rwmixwrite <= 100;rwmixwrite += 25))
do
for ((iodepth = 8; iodepth <= 128; iodepth = iodepth * 2 ))
do
for ((num = 1; num <= 23; num+=11 ))
do
for((repeat = 1; repeat <= 3; repeat++))
do
    echo "rw= "$rw "bs= "$bs"k" "rwmixwrite= "$rwmixwrite "iodepth="$iodepth "num= "$num "repeat="$repeat 
    fio --direct=1 --ioengine=libaio --group_reporting=1 --size=15G --group_reporting --time_based --runtime=180 --iodepth=$iodepth --numjobs=$num --bs=$bs'k' --rw=$rw --cpus_allowed=0-23 --name=nvme0n1 --filename=/dev/nvme0n1 --output=test$bs'k'-$rwmixwrite-$iodepth-$num-$repeat --output-format=json --rwmixwrite=$rwmixwrite
done
done
done
done
done