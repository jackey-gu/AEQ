# -*- coding:utf8 -*-
import  json
from os import listdir
import os
import xlwt
import xlrd
from xlutils.copy import copy

path = 'C:/Users/jackey_gu/Desktop/实验数据/SSDi12'
 
filelist = listdir(path)
#for i in  filelist:
#print(filelist[0].split(".")[0])
 #   i.split()
fileIndex =[]


# 打开已有excel工作表
oldWb = xlrd.open_workbook('C:/Users/jackey_gu/Desktop/实验数据/SSDi12.xls')
newWb = copy(oldWb)#复制
newWs = newWb.get_sheet(0);#取sheet表

#文件名载入
bs = 64
iodepth = 8
rwmixwrite = 0
num = 1
repeat = 1
while bs <= 64:  
    while rwmixwrite <= 0:  
        while iodepth <= 128:
            while num < 24:          
                while repeat <= 3: 
                    output="test"+str(bs)+'k'+'-'+str(rwmixwrite)+'-'+str(iodepth)+'-'+str(num)+'-'+str(repeat)
                    fileIndex.append(output)
                    #print(output)
                    repeat += 1
                repeat = 1    
                num += 11
            num = 1
            iodepth = iodepth * 2  
        iodepth = 8      
        rwmixwrite += 25 
    rwmixwrite = 0   
    bs *= 2
#print(fileIndex)


# 设置表头,第零行内容
#worksheet.write(0, 0, label='bs-rwmix-iodepth-num-repeat')
#worksheet.write(0, 1, label='read_lat')
#worksheet.write(0, 2, label='read_95_lat')
#worksheet.write(0, 3, label='read_99_lat')
#worksheet.write(0, 4, label='read_bw_kb')
#worksheet.write(0, 5, label='read_iops')
#worksheet.write(0, 6, label='write_lat')
#worksheet.write(0, 7, label='write_95_lat')
#worksheet.write(0, 8, label='write_99_lat')
#worksheet.write(0, 9, label='write_bw_kb')
#worksheet.write(0, 10, label='write_iops')
#worksheet.write(0, 11, label='sys_cpu')


# 将json字典写入excel
# 变量用来循环时控制写入单元格，感觉有更好的表达方式

row0 = 1
column0 = 0
row1 = 901


#完成排序后，开始按照文件名顺序读取文件内容信息
#记录每个文件最终信息的列表
labelpath = 'C:/Users/jackey_gu/Desktop/实验数据/SSDi12/'
for file in fileIndex:
    #print(file)
    # 读取json文件
    newWs.write(row1,column0,file)
    with open(labelpath + file, 'r') as f:
        data = json.load(f)
        #print(data)
        # 写入内容  ws.write(a, b, c)  a：行，b：列，c：内容
        val1 = data['jobs'][0]['read']['clat_ns']['mean']
        val2 = data['jobs'][0]['read']['clat_ns']['percentile']['95.000000']
        val3 = data['jobs'][0]['read']['clat_ns']['percentile']['99.000000']
        val4 = data['jobs'][0]['read']['bw']
        val5 = data['jobs'][0]['read']['iops']
        val6 = data['jobs'][0]['write']['clat_ns']['mean']
        val7 = data['jobs'][0]['write']['clat_ns']['percentile']['95.000000']
        val8 = data['jobs'][0]['write']['clat_ns']['percentile']['99.000000']
        val9 = data['jobs'][0]['write']['bw']
        val10 = data['jobs'][0]['write']['iops']
        val11 = data['jobs'][0]['sys_cpu']
        newWs.write(row1,1,val1)
        newWs.write(row1,2,val2)
        newWs.write(row1,3,val3)
        newWs.write(row1,4,val4)
        newWs.write(row1,5,val5)
        newWs.write(row1,6,val6)
        newWs.write(row1,7,val7)
        newWs.write(row1,8,val8)
        newWs.write(row1,9,val9)
        newWs.write(row1,10,val10)
        newWs.write(row1,11,val11)
        #print(val1) 
        
    row1 += 1
    #row0 += 1


newWs.write(2, 4, "pass");#写入 2行4列写入pass
newWb.save('C:/Users/jackey_gu/Desktop/实验数据/test.xls'); #保存至result路径

# 表格保存
#workbook.save('SSDi12.xls')